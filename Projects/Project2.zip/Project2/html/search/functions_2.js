var searchData=
[
  ['dealer',['Dealer',['../class_dealer.html#a6b2f0b132a7aac7650308365f9bb5cd7',1,'Dealer::Dealer()'],['../class_dealer.html#aff6d17c7752adcbc772387fcde2abe8c',1,'Dealer::Dealer(const Dealer &amp;orig)']]]
];
