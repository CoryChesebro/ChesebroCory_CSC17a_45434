var searchData=
[
  ['hand',['hand',['../class_player.html#aa3254d052976bd98168b10a922f89d79',1,'Player']]]
];
