var searchData=
[
  ['total',['total',['../class_player.html#af20c83ae46c2128a207deccfef3634ee',1,'Player']]]
];
