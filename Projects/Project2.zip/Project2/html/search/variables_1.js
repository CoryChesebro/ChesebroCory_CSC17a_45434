var searchData=
[
  ['dealer',['dealer',['../class_game.html#a4c61a51d11d4e6ab3e92e8c8bb0b9750',1,'Game']]]
];
