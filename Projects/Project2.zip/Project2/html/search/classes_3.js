var searchData=
[
  ['user',['User',['../class_user.html',1,'']]],
  ['user_3c_20int_20_3e',['User&lt; int &gt;',['../class_user.html',1,'']]]
];
