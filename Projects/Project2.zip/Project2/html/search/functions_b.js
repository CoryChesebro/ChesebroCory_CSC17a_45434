var searchData=
[
  ['user',['User',['../class_user.html#af92a4f4ff6c72a78e2350a1091a084d9',1,'User::User()'],['../class_user.html#ae52b993308c967e4f110315c28d9cf53',1,'User::User(const User &amp;orig)']]]
];
