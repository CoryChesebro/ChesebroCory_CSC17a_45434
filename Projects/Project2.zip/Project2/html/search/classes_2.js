var searchData=
[
  ['player',['Player',['../class_player.html',1,'']]],
  ['player_3c_20int_20_3e',['Player&lt; int &gt;',['../class_player.html',1,'']]]
];
