var searchData=
[
  ['banner',['banner',['../main_8cpp.html#adbca3528ba29d3d93508d9b0e695a6e0',1,'main.cpp']]]
];
