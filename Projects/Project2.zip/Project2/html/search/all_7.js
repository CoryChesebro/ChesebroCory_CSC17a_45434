var searchData=
[
  ['operator_2b_2b',['operator++',['../class_dealer.html#a4425aecd1c3643743887776e37cac2ec',1,'Dealer::operator++()'],['../class_player.html#a765ffde62f4ca315f5080d23b7a89df6',1,'Player::operator++()'],['../class_user.html#a12cd255413c9b349c2d9274e8e5260b1',1,'User::operator++()']]],
  ['operator_2d_2d',['operator--',['../class_dealer.html#a8497cc0819416907d4c7496fd880627a',1,'Dealer::operator--()'],['../class_player.html#a34001e45bcbd5aa4c039b9d73a8c3ede',1,'Player::operator--()'],['../class_user.html#a79b5a45060baa7b9d20c6e6f8a320b37',1,'User::operator--()']]]
];
