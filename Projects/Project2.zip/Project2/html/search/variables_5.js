var searchData=
[
  ['size',['size',['../class_player.html#a7d6242e043b6379298c5fca6c5fded95',1,'Player']]]
];
