/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Employee.h
 * Author: Cory
 *
 * Created on July 15, 2018, 1:11 AM
 */

#ifndef EMPLOYEE_H
#define EMPLOYEE_H

struct Employee{
    std::string name;
    int hours;
    float rop;
    int total;
    float cents;
};

#endif /* EMPLOYEE_H */

